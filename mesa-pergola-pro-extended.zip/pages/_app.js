import '@/styles/globals.css'
import { DefaultSeo } from 'next-seo'

export default function App({ Component, pageProps }) {
  return (
    <>
      <DefaultSeo
        title="Mesa Pergola - Pergola, Cam Balkon, Sineklik"
        description="Mesa Pergola: Pergola, cam balkon, sineklik sistemlerinde profesyonel çözümler."
        openGraph={{
          type: 'website',
          locale: 'tr_TR',
          url: 'https://mesa-pergola.vercel.app/',
          site_name: 'Mesa Pergola',
        }}
        twitter={{ handle: '@mesa_pergola', site: '@mesa_pergola', cardType: 'summary_large_image' }}
      />
      <Component {...pageProps} />
    </>
  )
}
