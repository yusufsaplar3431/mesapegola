import { useState } from 'react'
import Image from 'next/image'
import Lightbox from 'react-image-lightbox'
import 'react-image-lightbox/style.css'
import WhatsAppButton from '@/components/WhatsAppButton'

export default function Home() {
  const categories = ["Hepsi","Pergola","Cam Balkon","Sineklik"]
  const images = Array.from({length:15}, (_,i)=>`/gallery/${i+1}.jpg`)
  const [isOpen, setIsOpen] = useState(false)
  const [photoIndex, setPhotoIndex] = useState(0)
  const [filter, setFilter] = useState("Hepsi")

  const filtered = images.filter((img,i)=>{
    if(filter==="Hepsi") return true
    if(filter==="Pergola") return i<5
    if(filter==="Cam Balkon") return i>=5 && i<10
    if(filter==="Sineklik") return i>=10
  })

  return (
    <main className="p-6 max-w-5xl mx-auto">
      <header className="text-center mb-8">
        <h1 className="text-4xl font-bold">Mesa Pergola</h1>
        <p className="text-lg text-gray-600">Pergola, Cam Balkon, Sineklik Sistemleri</p>
      </header>

      <div className="flex justify-center mb-6 gap-2 flex-wrap">
        {categories.map(c=>(
          <button key={c} onClick={()=>setFilter(c)} className={`px-4 py-2 rounded ${filter===c?'bg-blue-600 text-white':'bg-gray-200'}`}>{c}</button>
        ))}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {filtered.map((src,idx)=>(
          <div key={idx} onClick={()=>{setIsOpen(true); setPhotoIndex(idx)}} className="cursor-pointer">
            <Image src={src} alt="" width={300} height={200} className="rounded shadow" />
          </div>
        ))}
      </div>

      {isOpen && (
        <Lightbox
          mainSrc={filtered[photoIndex]}
          nextSrc={filtered[(photoIndex+1)%filtered.length]}
          prevSrc={filtered[(photoIndex+filtered.length-1)%filtered.length]}
          onCloseRequest={()=>setIsOpen(false)}
          onMovePrevRequest={()=>setPhotoIndex((photoIndex+filtered.length-1)%filtered.length)}
          onMoveNextRequest={()=>setPhotoIndex((photoIndex+1)%filtered.length)}
        />
      )}

      <footer className="text-center mt-8">
        <p>İletişim: <a href="tel:+905443225340" className="text-blue-500">+90 544 322 5340</a></p>
      </footer>

      <WhatsAppButton />
    </main>
  )
}
